<?php
//error_reporting(E_ERROR | E_PARSE);

//GENERAL
define("SITETITLE", "Movieholic");
define("OMDB_API", "a17a6a6a");
define("FILE_GENRES", "genres.txt");

//DATABASE
define("DBHOST", "localhost");
define("DBUSER", "root");
define("DBPASS", "");
define("DBNAME", "moviedb");

?>