<?php
/**
 * Function to display the standard footer for the page
  */

function stdFoot(){
    ?>
               </div>
          </div>
        </div>
    </body>
</html>
    <?php
}